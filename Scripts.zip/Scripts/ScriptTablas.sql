USE [PruebaNexus]
GO

/****** Object:  Table [dbo].[Consulta]    Script Date: 13/07/2020 6:16:09 a. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Consulta](
	[IdConsulta] [bigint] IDENTITY(1,1) NOT NULL,
	[IdDoctor] [bigint] NOT NULL,
	[IdPaciente] [bigint] NOT NULL,
	[FechaConsulta] [datetime] NOT NULL,
	[ConsultorioCita] [varchar](100) NOT NULL,
 CONSTRAINT [PK_Consulta] PRIMARY KEY CLUSTERED 
(
	[IdConsulta] ASC,
	[IdDoctor] ASC,
	[IdPaciente] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Consulta]  WITH CHECK ADD  CONSTRAINT [FK_Consulta_Doctores] FOREIGN KEY([IdDoctor])
REFERENCES [dbo].[Doctores] ([IdDoctor])
GO

ALTER TABLE [dbo].[Consulta] CHECK CONSTRAINT [FK_Consulta_Doctores]
GO

ALTER TABLE [dbo].[Consulta]  WITH CHECK ADD  CONSTRAINT [FK_Consulta_Pacientes] FOREIGN KEY([IdPaciente])
REFERENCES [dbo].[Pacientes] ([IdPaciente])
GO

ALTER TABLE [dbo].[Consulta] CHECK CONSTRAINT [FK_Consulta_Pacientes]
GO
USE [PruebaNexus]
GO

/****** Object:  Table [dbo].[Doctores]    Script Date: 13/07/2020 6:16:23 a. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Doctores](
	[IdDoctor] [bigint] IDENTITY(1,1) NOT NULL,
	[NombresDoctor] [varchar](100) NOT NULL,
	[EspecialidadDoctor] [varchar](200) NOT NULL,
	[NumeroCredencialDoctor] [int] NOT NULL,
	[HospitalDoctor] [varchar](500) NOT NULL,
	[TelefonoDoctor] [int] NOT NULL,
	[IdentificacionDoctor] [int] NOT NULL,
 CONSTRAINT [PK_Doctores] PRIMARY KEY CLUSTERED 
(
	[IdDoctor] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO
USE [PruebaNexus]
GO

/****** Object:  Table [dbo].[Pacientes]    Script Date: 13/07/2020 6:16:39 a. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Pacientes](
	[IdPaciente] [bigint] IDENTITY(1,1) NOT NULL,
	[NombresPaciente] [varchar](100) NOT NULL,
	[IdentificacionPaciente] [int] NOT NULL,
	[NumeroSeguroPaciente] [nchar](10) NOT NULL,
	[TelefonoPaciente] [int] NOT NULL,
	[CodigoPostal] [int] NOT NULL,
	[correoElectronico] [varchar](500) NULL,
 CONSTRAINT [PK_Pacientes] PRIMARY KEY CLUSTERED 
(
	[IdPaciente] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO



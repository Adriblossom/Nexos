﻿using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using PruebaNexus.HttpHelper;

namespace PruebaNexus.Controller
{
    [Route("[controller]")]
    public class PacienteController: ControllerBase
    {
        private IConfiguration _configuration;

        public string uriAPI;
        // GET: /<controller>/
        public PacienteController(IConfiguration configuration)
        {
            _configuration = configuration;
            uriAPI = _configuration.GetSection("ConfiguracionServiciosAPI:ServiciosDistribuidos").Value;
        }
        // GET: api/<controller>
        [HttpGet("[action]")]
        public async Task<string> ConsultaPaciente()
        {
            string res = "";
            HttpResponseMessage serviceResponse = HttpClientHelper.ConsumirServicioRest(uriAPI + "Paciente/ConsultaPaciente", HttpMethod.Get, "", "");
            res = await serviceResponse.Content.ReadAsStringAsync();
            return res;
        }

    }
}

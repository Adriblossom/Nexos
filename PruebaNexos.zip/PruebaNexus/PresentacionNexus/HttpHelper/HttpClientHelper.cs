﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Newtonsoft.Json;

namespace PruebaNexus.HttpHelper
{
    public static class HttpClientHelper
    {
        private static HttpContent CreateHttpContent<T>(T content)
        {
            string json = JsonConvert.SerializeObject(content);
            return new StringContent(json, Encoding.UTF8, "application/json");
        }

        public static HttpResponseMessage ConsumirServicioRest<T>(string serviceUrl, HttpMethod Metodo, T content, string token, string username = null, string password = null)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

            string uri = serviceUrl;


            // Now create a client handler which uses that proxy
            var httpClientHandler = new HttpClientHandler
            {
                
            };

            using (var client = new HttpClient(httpClientHandler))
            {
                client.Timeout = TimeSpan.FromMinutes(5);
                var request = new HttpRequestMessage(Metodo, uri);
                if (!string.IsNullOrEmpty(content.ToString()))
                {
                    HttpContent httpContent = CreateHttpContent(content);
                    request.Content = httpContent;
                    request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                }
                if (!string.IsNullOrEmpty(token))
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                }
                HttpResponseMessage asyncRes = client.SendAsync(request).Result;

                return asyncRes;
            }


        }
    }
}

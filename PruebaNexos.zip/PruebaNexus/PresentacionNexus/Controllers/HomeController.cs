﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using PresentacionNexus.Models;
using PruebaNexus.HttpHelper;

namespace PresentacionNexus.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        private IConfiguration _configuration;

        public string uriAPI;

        public HomeController(IConfiguration configuration)
        {
            _configuration = configuration;
            uriAPI = _configuration.GetSection("ConfiguracionServiciosAPI:ServiciosDistribuidos").Value;
        }

        [HttpGet("[action]")]
        public async Task<string> ConsultaPaciente()
        {
            string res = "";
            HttpResponseMessage serviceResponse = HttpClientHelper.ConsumirServicioRest(uriAPI + "Paciente/ConsultaPaciente", HttpMethod.Get, "", "");
            res = await serviceResponse.Content.ReadAsStringAsync();
            return res;
        }

    }
}

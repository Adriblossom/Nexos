﻿using Aplicacion.ContextoPrincipal.Modelos;
using Aplicacion.ContextoPrincipal.Servicio.DoctoresServicio.Contrato;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServiciosDistribuidos.ContextoPrincipal.Controllers.DoctorControllers
{
    [ApiController]
    [Route("[controller]")]
    public class DoctorController : ControllerBase
    {
        IDoctorServicio _doctorServicio { get; }
        public DoctorController(IDoctorServicio doctorServicio)
        {
            _doctorServicio = doctorServicio;
        }

        [HttpGet]
        public async Task<IActionResult> ConsutaDoctores()
        {
            if (ModelState.IsValid)
            {
                var res = await _doctorServicio.ConsultaDoctor();

                return Ok(res);

            }
            return BadRequest();

        }

        [HttpPost("[action]")]
        public IActionResult ActualizarDoctor([FromBody] DoctorModel DoctorModel)
        {
            if (ModelState.IsValid)
            {
                var respuestaViewModel = _doctorServicio.ActualizarDoctor(DoctorModel);
                return Ok(respuestaViewModel);
            }
            return BadRequest();
        }

        [HttpPost("[action]")]
        public IActionResult InsertarDoctor([FromBody] DoctorModel DoctorModel)
        {
            if (ModelState.IsValid)
            {
                var respuestaViewModel = _doctorServicio.InsertarDoctor(DoctorModel);
                return Ok(respuestaViewModel);
            }
            return BadRequest();
        }

        [HttpPost("[action]")]
        public IActionResult EliminarDoctor([FromBody] string IdDoctor)
        {
            if (ModelState.IsValid)
            {
                var respuestaViewModel = _doctorServicio.EliminarDoctor(IdDoctor);
                return Ok(respuestaViewModel);
            }
            return BadRequest();
        }
    }
}

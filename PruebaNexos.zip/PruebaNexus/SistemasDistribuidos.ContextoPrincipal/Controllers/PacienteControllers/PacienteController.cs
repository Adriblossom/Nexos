﻿using Aplicacion.ContextoPrincipal.Modelos;
using Aplicacion.ContextoPrincipal.Servicio.PacientesServicio.Contrato;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServiciosDistribuidos.ContextoPrincipal.Controllers.PacienteControllers
{
    [ApiController]
    [Route("[controller]")]
    public class PacienteController : ControllerBase
    {
        IPacienteServicio _pacienteServicio { get; }
        public PacienteController(IPacienteServicio pacienteServicio)
        {
            _pacienteServicio = pacienteServicio;
        }

        [HttpGet]
        public async Task<IActionResult> ConsutaPacientes()
        {
            if (ModelState.IsValid)
            {
                var res = await _pacienteServicio.ConsultaPaciente();

                return Ok(res);

            }
            return BadRequest();

        }

        [HttpPost("[action]")]
        public IActionResult ActualizarPaciente([FromBody] PacienteModel PacienteModel)
        {
            if (ModelState.IsValid)
            {
                var respuestaViewModel = _pacienteServicio.ActualizarPaciente(PacienteModel);
                return Ok(respuestaViewModel);
            }
            return BadRequest();
        }

        [HttpPost("[action]")]
        public IActionResult InsertarPaciente([FromBody] PacienteModel PacienteModel)
        {
            if (ModelState.IsValid)
            {
                var respuestaViewModel = _pacienteServicio.InsertarPaciente(PacienteModel);
                return Ok(respuestaViewModel);
            }
            return BadRequest();
        }

        [HttpPost("[action]")]
        public IActionResult EliminarPaciente([FromBody] string IdPaciente)
        {
            if (ModelState.IsValid)
            {
                var respuestaViewModel = _pacienteServicio.EliminarPaciente(IdPaciente);
                return Ok(respuestaViewModel);
            }
            return BadRequest();
        }

    }
}

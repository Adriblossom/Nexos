﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Net.Http.Headers;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using System.Security.Claims;

namespace ServiciosDistribuidos.Filtros
{
    public class TokenValidationHandler 
    {
        private IConfiguration _configuration;
        public TokenValidationHandler(
          
            ILoggerFactory logger,
            UrlEncoder encoder,
        
            IConfiguration configuration
          ) 
        {
            _configuration = configuration;
        }
    }    
}

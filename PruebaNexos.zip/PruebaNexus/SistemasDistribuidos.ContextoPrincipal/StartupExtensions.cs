﻿#region Directivas
using Aplicacion.ContextoPrincipal.Servicio.PacientesServicio.Contrato;
using Aplicacion.ContextoPrincipal.Servicio.PacientesServicio.Implementacion;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Dominio.Contexto_Principal.modelos;
using Microsoft.AspNetCore.Builder;
#endregion

namespace ServiciosDistribuidos
{
    public static class StartupExtensions
    {

        public static void AddApplicationServices(this IServiceCollection services)
        {
            //Services            
            #region ModuloAdministracion
            services.AddScoped<IPacienteServicio, PacienteServicio>();
          
            #endregion
        }
        public static void AddInfraestructureRepositorys(this IServiceCollection services)
        {
            //repositorios
            #region ModuloAdministracion
           
           
            #endregion

           

        }
        
        public static void AddDatabaseContext(this IServiceCollection services, IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString(nameof(PruebaNexusContext));
            services.AddDbContext<PruebaNexusContext>();
        }
        public static void AddSerilogFactory(this IServiceCollection services, IConfiguration configuration)
        {
            if (configuration != null)
            {

                services.AddScoped<Transversal.Log.Contrato.ISerilogFactory, Transversal.Log.Implementacion.SerilogLoggerFactory>();
                services.BuildServiceProvider().GetService<Microsoft.Extensions.Logging.ILogger>();
                var serilogConfig = configuration.GetSection(nameof(Transversal.Model.SerilogConfig));

                var serilogConfigModel = new Transversal.Model.SerilogConfig()
                {
                    ConnectionStrings = configuration.GetConnectionString("SerilogContexto"),
                    NombreSchema = serilogConfig[nameof(Transversal.Model.SerilogConfig.NombreSchema)],
                    NombreTabla = serilogConfig[nameof(Transversal.Model.SerilogConfig.NombreTabla)]
                };

                
            }

        }
        
        public static void UseHealthChecks(this Microsoft.AspNetCore.Builder.IApplicationBuilder application)
        {
            
        }
        public static void UseSwaggerUI(this IApplicationBuilder application)
        {
            application.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "API V1");
                c.DefaultModelExpandDepth(0);
                c.DefaultModelsExpandDepth(-1);
            });
        }
        public static void UseSwaggerPersonality(this IServiceCollection services)
        {
          
        }
    }
}

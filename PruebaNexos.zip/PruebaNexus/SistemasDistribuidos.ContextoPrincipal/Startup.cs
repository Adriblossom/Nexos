using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Mvc;
using ServiciosDistribuidos.Filtros;




namespace SistemasDistribuidos.ContextoPrincipal
{
    public class Startup
    {
        public Startup(IHostingEnvironment environment)
        {
            Configuration = Configuration;
            Environment = environment;
        }

        public IConfiguration Configuration { get; }

        private IHostingEnvironment Environment { get; }

        //This method gets called by the runtime.Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
          
            services.AddHttpContextAccessor();


            services.AddMvcCore(options =>
            {
                options.Filters.Add(new ValidateModelAttribute());
            }).SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            // Region Cookies

            services.AddCors(options =>
            {
                options.AddPolicy("AllowCredentials", builder =>
                {
                    builder.WithOrigins("https://localhost:44394")
                        .AllowAnyMethod()
                        .AllowCredentials()
                        .AllowAnyHeader();
                });
            });
           
            
          
            services.AddDistributedMemoryCache();
           


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app)
        {

            //app.UseExceptionMiddleware(Environment);
            app.UseCors("AllowCredentials");
             app.UseSwagger();
            app.UseSwaggerUI(c =>
            {

                c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");

            });
            app.UseMvc();
        }
    
    }
}

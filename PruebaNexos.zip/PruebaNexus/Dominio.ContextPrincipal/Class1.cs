﻿using System;

namespace Dominio.ContextPrincipal
{
    public class Class1
    {
    }
}

﻿namespace Dominio.Nucleo
{
    public abstract class Entity
    {

    }
}

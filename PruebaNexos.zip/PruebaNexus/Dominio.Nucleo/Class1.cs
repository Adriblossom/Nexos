﻿using System;

namespace Dominio.Nucleo
{
    public class Class1
    {
    }
}

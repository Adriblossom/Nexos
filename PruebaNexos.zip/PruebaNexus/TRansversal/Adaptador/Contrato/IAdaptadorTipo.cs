﻿using System.Collections.Generic;

namespace Infraestructura.Transversal.Adaptador
{
    public interface IAdaptadorTipo
    {

        #region Métodos

        /// <summary>
        /// Adapt a source object to an instance of type <typeparam name="TTarget">Type of source item</typeparam>
        /// </summary>
        /// <typeparam name="TSource">Type of source item</typeparam>
        /// <typeparam name="TTarget">Type of target item</typeparam>
        /// <param name="source">Instance to adapt</param>
        /// <returns><paramref name="source"/> mapped to <typeparamref name="TTarget"/></returns>
        TTarget Adapt<TSource, TTarget>(TSource source)
            where TTarget : class, new()
            where TSource : class;


        /// <summary>
        /// Adapt a source object to an instnace of type <typeparam name="TTarget">Type of source item</typeparam>
        /// </summary>
        /// <typeparam name="TTarget">Type of target item</typeparam>
        /// <param name="source">Instance to adapt</param>
        /// <returns><paramref name="source"/> mapped to <typeparamref name="TTarget"/></returns>
        /// <history>
        TTarget Adapt<TTarget>(object source)
            where TTarget : class, new();

        /// <summary>
        /// <see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/>
        /// </summary>
        /// <typeparam name="TSource"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></typeparam>
        /// <typeparam name="TTarget"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></typeparam>
        /// <param name="t"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></param>
        /// <returns><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></returns>

        List<TTarget> Adapt<TSource, TTarget>(List<TSource> t);

        /// <summary>
        /// <see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/>
        /// </summary>
        /// <typeparam name="TSource"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></typeparam>
        /// <typeparam name="TTarget"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></typeparam>
        /// <param name="t"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></param>
        /// <returns><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></returns>
        IEnumerable<TTarget> Adapt<TSource, TTarget>(IEnumerable<TSource> t);


        /// <summary>
        /// Adapt a source object to an instance of type <typeparam name="TTarget">Type of source item</typeparam>
        /// </summary>
        /// <typeparam name="TSource">Type of source item</typeparam>
        /// <typeparam name="TTarget">Type of target item</typeparam>
        /// <param name="source">Instance to adapt</param>
        /// <param name="llaveEncriptacion">valores de la llave asociados a la entidad</param>
        /// <param name="cifradoEstatico">Indica si se debe utilizar cifrado estático</param>
        /// <returns><paramref name="source"/> mapped to <typeparamref name="TTarget"/></returns>
        TTarget Adapt<TSource, TTarget>(TSource source, string llaveEncriptacion, bool cifradoEstatico = false)
            where TTarget : class, new()
            where TSource : class;

        #endregion

    }
}

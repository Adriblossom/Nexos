﻿namespace Infraestructura.Transversal.Adaptador
{
    public interface IAdaptadorTipoFactory
    {

        #region Métodos

        /// <summary>
        /// Create a type adater
        /// </summary>
        /// <returns>The created IAdaptadorTipo</returns>
        IAdaptadorTipo Create();

        #endregion

    }
}

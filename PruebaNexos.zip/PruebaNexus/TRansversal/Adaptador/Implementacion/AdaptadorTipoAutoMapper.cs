﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infraestructura.Transversal.Adaptador
{
    public class AdaptadorTipoAutoMapper
         : IAdaptadorTipo
    {

        #region Miembros

        private IMapper _mapper = null;

        #endregion

        #region Constructores

        /// <summary>
        /// Crea una nueva instancia que adapta según el mapeador recibido
        /// </summary>
        /// <param name="mapper">mapper</param>
        public AdaptadorTipoAutoMapper(IMapper mapper)
        {
            _mapper = mapper;
        }

        #endregion

        #region IAdaptadorTipo Members

        /// <summary>
        /// <see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/>
        /// </summary>
        /// <typeparam name="TSource"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></typeparam>
        /// <typeparam name="TTarget"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></typeparam>
        /// <param name="source"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></param>
        /// <returns><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></returns>
        public TTarget Adapt<TSource, TTarget>(TSource source)
            where TSource : class
            where TTarget : class, new()
        {
            return _mapper.Map<TSource, TTarget>(source);
        }

        /// <summary>
        /// <see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/>
        /// </summary>
        /// <typeparam name="TTarget"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></typeparam>
        /// <param name="source"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></param>
        /// <returns><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></returns>
        public TTarget Adapt<TTarget>(object source) where TTarget : class, new()
        {
            return _mapper.Map<TTarget>(source);
        }

        /// <summary>
        /// <see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/>
        /// </summary>
        /// <typeparam name="TSource"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></typeparam>
        /// <typeparam name="TTarget"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></typeparam>
        /// <param name="source"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></param>
        /// <returns><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></returns>
        public List<TTarget> Adapt<TSource, TTarget>(List<TSource> source)
        {
            List<TTarget> target = new List<TTarget>(0);

            source.ForEach(s =>
            {
                target.Add(_mapper.Map<TSource, TTarget>(s));
            });

            return target;
        }

        /// <summary>
        /// <see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/>
        /// </summary>
        /// <typeparam name="TSource"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></typeparam>
        /// <typeparam name="TTarget"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></typeparam>
        /// <param name="source"><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></param>
        /// <returns><see cref="Infraestructura.Transversales.Nucleo.Adaptadores.IAdaptadorTipo"/></returns>
        public IEnumerable<TTarget> Adapt<TSource, TTarget>(IEnumerable<TSource> source)
        {
            List<TTarget> target = new List<TTarget>(0);

            source.ToList().ForEach(s =>
            {
                target.Add(_mapper.Map<TSource, TTarget>(s));
            });

            return target;
        }

        public TTarget Adapt<TSource, TTarget>(TSource source, string llaveEncriptacion, bool cifradoEstatico = false)
            where TSource : class
            where TTarget : class, new()
        {
            return _mapper.Map<TSource, TTarget>(source, opt =>
            {
                opt.Items[nameof(llaveEncriptacion)] = llaveEncriptacion;
                opt.Items[nameof(cifradoEstatico)] = cifradoEstatico;
            });
        }

        #endregion

    }
}

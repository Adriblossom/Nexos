﻿namespace Infraestructura.Transversal.Localizacion
{
    public interface ILocalizationFactory
    {
        ILocalization Create();
    }

}

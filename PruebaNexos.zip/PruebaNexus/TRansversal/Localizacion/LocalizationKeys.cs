﻿namespace Infraestructura.Transversal.Localizacion
{
    public class LocalizationKeys
    {
        public enum Aplicacion
        {
            information_SussesRequest,
            information_FailRequest,
            exception_ErrorAdiconarEntidad,
            validation_Exception,
            warning_adicionarempresamodelnull,
            warning_contactomodelnull,
            warning_usuariografomodelnull,
            warning_firmamodelnull,
            warning_solicitudfirmamodelnull,
            warning_tipofirmamodelnull,
            warning_tipoejecucionmodelnull,
            warning_procesofirmamodelnull,
            warning_grupomodelnull,
            warning_notificacionmodelnull,
            warning_notificacioncontactomodelnull,
            warning_tiponotificacionmodelnull,
            warning_grupocontactomodelnull,
            warning_adicionararchivomodelnull,
            warning_adicionartrazamodelnull,
            warning_personaModelnull,
            warning_historialModelnull,
            warning_LoginModelnull,
            ValidacionCampo,
            validation_ATDP,
            validation_CampoPlantilla,
            validation_Pagare,
            validation_File,
            validation_File_OK,
            http_Exception,
            Certificate_Not_Configured
        }

        public enum Infraestructura
        {
            exception_InvalidEnumeratedType,

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Transversal.Excepcion
{
    public enum PoliticaExcepcionEnum
    {
       
            NoDefinida,
            Infraestructura,
            Dominio,
            Aplicacion,
            SistemasDistribuidos,
            Presentacion,
            Fachada,
            PresentacionAplicacion,
            PresentacionMovil,      
    }
}

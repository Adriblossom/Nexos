﻿using Transversal.Excepcion;
using Transversal.Log.Contrato;
using System;
using Transversal.Log.Mensajes;

namespace Infraestructura.Transversal.Log.Implementacion
{
    public class SerilogFactory 
    {
        static ISerilogFactory _currentSerilogFactory = null;
        static ISerilog _currentSerilog = null;

        #region Public Methods

        public static void SetCurrent(ISerilogFactory serilogFactory)
        {
            _currentSerilogFactory = serilogFactory;
        }


        public static ISerilog Create()
        {
            if (_currentSerilogFactory == null)
                throw new ApplicationException(Recursos.Excepcion_SerilogFactory);

            if (_currentSerilog == null)
                _currentSerilog = _currentSerilogFactory.Create();

            return _currentSerilog;
        }

        #endregion
    }
}

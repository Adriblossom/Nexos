﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Transversal.Log.Implementacion
{
    public enum SerilogTableEnum
    {
        LogId,
        LogMensaje,
        LogExcepcion,
        LogDetalleExcepcion,
        LogFecha,
        LogPropiedades,
        LogTipo,
        LogGUIDMesaAyuda,
        LogNombreMaquina,
        LogCapaAplicacion
    }

}

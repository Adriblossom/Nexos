﻿using Serilog;
using System;
using Transversal.Excepcion;
using Transversal.Log.Contrato;

namespace Transversal.Log.Implementacion
{
    public class SerilogLogger : ISerilog
    {

        private ILogger _logger = null;

        public SerilogLogger(ILogger logger)
        {
            _logger = logger;
        }

        public void LogError(string mensaje, PoliticaExcepcionEnum politicaExcepcionEnum, Exception exception, string nombreMaquina)
        {
            _logger.ForContext(SerilogTableEnum.LogNombreMaquina.ToString(), nombreMaquina)
                   .ForContext(SerilogTableEnum.LogCapaAplicacion.ToString(), politicaExcepcionEnum.ToString())
                   .Error(exception, mensaje);


        }

        public void LogError(string mensaje, Exception exception)
        {
            _logger.Error(exception, mensaje);
        }

        public void LogInformation(string mensaje, PoliticaExcepcionEnum politicaExcepcionEnum, string nombreMaquina = null, params object[] args)
        {
            _logger.ForContext(SerilogTableEnum.LogNombreMaquina.ToString(), nombreMaquina)
                   .ForContext(SerilogTableEnum.LogCapaAplicacion.ToString(), politicaExcepcionEnum.ToString())
                   .Information(mensaje, args);
        }

        public void LogWarning(string mensaje, PoliticaExcepcionEnum politicaExcepcionEnum, string nombreMaquina, params object[] args)
        {
            _logger.ForContext(SerilogTableEnum.LogNombreMaquina.ToString(), nombreMaquina)
                   .ForContext(SerilogTableEnum.LogCapaAplicacion.ToString(), politicaExcepcionEnum.ToString())
                   .Warning(mensaje, args);
        }
    }
}

﻿using Transversal.Log.Contrato;
using Serilog;
using Serilog.Events;
using Serilog.Sinks.MSSqlServer;
using System;
using System.Collections.ObjectModel;
using System.Data;
using Transversal.Model;

namespace Transversal.Log.Implementacion
{
    public class SerilogLoggerFactory: ISerilogFactory
    {
        private ILogger _logger = null;

        public SerilogLoggerFactory(SerilogConfig serilogConfig)
        {
            var ColumnasTablaLogs = new ColumnOptions();

            ColumnasTablaLogs.Id.ColumnName = SerilogTableEnum.LogId.ToString();
            ColumnasTablaLogs.Message.ColumnName = SerilogTableEnum.LogMensaje.ToString();
            ColumnasTablaLogs.Exception.ColumnName = SerilogTableEnum.LogExcepcion.ToString();
            ColumnasTablaLogs.MessageTemplate.ColumnName = SerilogTableEnum.LogDetalleExcepcion.ToString();
            ColumnasTablaLogs.TimeStamp.ColumnName = SerilogTableEnum.LogFecha.ToString();
            ColumnasTablaLogs.Properties.ColumnName = SerilogTableEnum.LogPropiedades.ToString();
            ColumnasTablaLogs.Properties.RootElementName = "Exception";
            ColumnasTablaLogs.Level.ColumnName = SerilogTableEnum.LogTipo.ToString(); ;

            ColumnasTablaLogs.AdditionalDataColumns = new Collection<DataColumn>
            {
                new DataColumn {DataType = typeof(string), ColumnName =SerilogTableEnum.LogCapaAplicacion.ToString()},
                new DataColumn {DataType = typeof(Guid), ColumnName = SerilogTableEnum.LogGUIDMesaAyuda.ToString(), DefaultValue = Guid.NewGuid()},
                new DataColumn {DataType = typeof(string), ColumnName =SerilogTableEnum.LogNombreMaquina.ToString()},
            };

            _logger = new LoggerConfiguration().WriteTo.
                MSSqlServer(serilogConfig.ConnectionStrings, tableName: serilogConfig.NombreTabla, schemaName: serilogConfig.NombreSchema,
                restrictedToMinimumLevel: LogEventLevel.Information,
                autoCreateSqlTable: true,
                columnOptions: ColumnasTablaLogs
                ).CreateLogger();

        }

        public ISerilog Create()
        {
            return new SerilogLogger(_logger);
        }
    }
}

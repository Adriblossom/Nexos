﻿using Transversal.Excepcion;

using System;

namespace Transversal.Log.Contrato
{
    public interface ISerilog
    {
        /// <summary>
        /// Log de información
        /// </summary>
        /// <param name="mensaje">mensaje</param>
        /// <param name="args">argumentos</param>
        void LogInformation(string mensaje, PoliticaExcepcionEnum politicaExcepcionEnum, string nombreMaquina, params object[] args);

        /// <summary>
        /// Log de advertencia
        /// </summary>
        /// <param name="mensaje">mensaje</param>
        /// <param name="args">argumentos</param>
        void LogWarning(string mensaje, PoliticaExcepcionEnum politicaExcepcionEnum, string nombreMaquina, params object[] args);

        /// <summary>
        /// Log de Error Simple
        /// </summary>
        /// <param name="mensaje">mensaje</param>
        void LogError(string mensaje, Exception exception);

        /// <summary>
        /// Log de Error Detallado
        /// </summary>
        /// <param name="mensaje">mensaje</param>
        /// <param name="exception">excepción</param>
        void LogError(string mensaje, PoliticaExcepcionEnum politicaExcepcionEnum, Exception exception, string nombreMaquina);
    }
}

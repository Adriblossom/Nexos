﻿

namespace Transversal.Log.Contrato
{
    public interface ISerilogFactory
    {
        ISerilog Create();
    }
}

﻿using Infraestructura.Transversal.Localizacion;

namespace Transversal.Mensajes
{
    public class ResourcesManagerFactory : ILocalizationFactory
    {
        public ILocalization Create()
        {
            return new ResourcesManager();
        }
    }
}

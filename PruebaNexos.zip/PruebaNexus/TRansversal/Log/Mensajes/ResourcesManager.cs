﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Text;
using Infraestructura.Transversal.Localizacion;
using Transversal.Log.Mensajes;

namespace Transversal.Mensajes
{
    public class ResourcesManager : ILocalization
    {
        #region Members
        ResourceManager _ResourceManager;
        #endregion

        #region Properties
        public ResourceManager ResourceManager
        {
            get { return _ResourceManager; }
        }
        #endregion

        #region Constructor
        public ResourcesManager()
        {
            _ResourceManager = new ResourceManager(typeof(Recursos));
        }
        #endregion

        #region Private Methods
        private string GetKeyFromEnum<T>(T key) where T : struct, IConvertible
        {
            if (!typeof(T).GetTypeInfo().IsEnum)
            {
                throw new ArgumentException(LocalizationFactory.CreateLocalResources().GetStringResource(LocalizationKeys.Infraestructura.exception_InvalidEnumeratedType));
            }

            return string.Format("{0}_{1}", typeof(T).Name, key.ToString());
        }
        #endregion

        #region Public Methods
        public string GetStringResource(string key)
        {
            return _ResourceManager.GetString(key);
        }

        public string GetStringResource(string key, CultureInfo culture)
        {
            return _ResourceManager.GetString(key, culture);
        }

        public string GetStringResource<T>(T key) where T : struct, IConvertible
        {
            return _ResourceManager.GetString(GetKeyFromEnum<T>(key));
        }

        public string GetStringResource<T>(T key, CultureInfo culture) where T : struct, IConvertible
        {
            return _ResourceManager.GetString(GetKeyFromEnum<T>(key), culture);
        }
        #endregion
    }
}

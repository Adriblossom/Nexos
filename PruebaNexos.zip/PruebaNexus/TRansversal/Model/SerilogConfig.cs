﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Transversal.Model
{
    public class SerilogConfig
    {
        public string ConnectionStrings { get; set; }
        public string NombreTabla { get; set; }
        public string NombreSchema { get; set; }
        public string NivelLog { get; set; }
    }
}

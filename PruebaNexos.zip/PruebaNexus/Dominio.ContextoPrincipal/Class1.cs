﻿using System;

namespace Dominio.ContextoPrincipal
{
    public class Class1
    {
    }
}

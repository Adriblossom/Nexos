﻿using System;

namespace Dominio.Contexto_Principal
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}

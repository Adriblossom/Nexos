﻿using Dominio.Contexto_Principal.modelos;
using Dominio.Nucleo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio.Contexto_Principal.Repositorio
{
    public interface IPacienteRepositorio : IRepositorioBase<Pacientes>
    {

    }
}

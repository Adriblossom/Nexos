﻿using Dominio.Contexto_Principal.modelos;
using Dominio.Nucleo;
using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio.Contexto_Principal.Repositorio.ImplementacionRepositorio
{
    public class DoctorRepositorio
    {
        #region
        private readonly PruebaNexusContext _unidadTrabajoContexto;
        public IUnidadTrabajo PruebaNexusContext => (IUnidadTrabajo)_unidadTrabajoContexto;
        #endregion

        #region Constructor
        public DoctorRepositorio(PruebaNexusContext unidadTrabajoContexto)
        {
            _unidadTrabajoContexto = unidadTrabajoContexto ?? throw new ArgumentNullException(nameof(unidadTrabajoContexto));
        }
        #endregion
    }
}

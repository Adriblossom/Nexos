﻿using Dominio.Nucleo;
using System;
using System.Collections.Generic;

namespace Dominio.Contexto_Principal.modelos
{
    public partial class Pacientes: Entity
    {
        public Pacientes()
        {
            Consulta = new HashSet<Consulta>();
        }

        public long IdPaciente { get; set; }
        public string NombresPaciente { get; set; }
        public int IdentificacionPaciente { get; set; }
        public string NumeroSeguroPaciente { get; set; }
        public int TelefonoPaciente { get; set; }
        public int CodigoPostal { get; set; }
        public string CorreoElectronico { get; set; }

        public virtual ICollection<Consulta> Consulta { get; set; }
    }
}

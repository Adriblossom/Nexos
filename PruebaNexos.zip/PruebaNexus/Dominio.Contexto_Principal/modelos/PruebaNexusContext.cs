﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Dominio.Contexto_Principal.modelos
{
    public partial class PruebaNexusContext : DbContext
    {
        public PruebaNexusContext()
        {
        }

        public PruebaNexusContext(DbContextOptions<PruebaNexusContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Consulta> Consulta { get; set; }
        public virtual DbSet<Doctores> Doctores { get; set; }
        public virtual DbSet<Pacientes> Pacientes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=LAPTOP-IIPRT7PT\\SQLEXPRESS;Database=PruebaNexus;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.0-rtm-35687");

            modelBuilder.Entity<Consulta>(entity =>
            {
                entity.HasKey(e => new { e.IdConsulta, e.IdDoctor, e.IdPaciente });

                entity.Property(e => e.IdConsulta).ValueGeneratedOnAdd();

                entity.Property(e => e.ConsultorioCita)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FechaConsulta).HasColumnType("datetime");

                entity.HasOne(d => d.IdDoctorNavigation)
                    .WithMany(p => p.Consulta)
                    .HasForeignKey(d => d.IdDoctor)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Consulta_Doctores");

                entity.HasOne(d => d.IdPacienteNavigation)
                    .WithMany(p => p.Consulta)
                    .HasForeignKey(d => d.IdPaciente)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Consulta_Pacientes");
            });

            modelBuilder.Entity<Doctores>(entity =>
            {
                entity.HasKey(e => e.IdDoctor);

                entity.Property(e => e.EspecialidadDoctor)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.HospitalDoctor)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.NombresDoctor)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Pacientes>(entity =>
            {
                entity.HasKey(e => e.IdPaciente);

                entity.HasIndex(e => e.CorreoElectronico)
                    .HasName("IX_Pacientes")
                    .IsUnique();

                entity.HasIndex(e => e.IdentificacionPaciente)
                    .HasName("IX_Pacientes_1")
                    .IsUnique();

                entity.Property(e => e.CorreoElectronico)
                    .HasColumnName("correoElectronico")
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.NombresPaciente)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.NumeroSeguroPaciente)
                    .IsRequired()
                    .HasMaxLength(10);
            });
        }
    }
}

﻿using Dominio.Nucleo;
using System;
using System.Collections.Generic;

namespace Dominio.Contexto_Principal.modelos
{
    public partial class Doctores: Entity
    {
        public Doctores()
        {
            Consulta = new HashSet<Consulta>();
        }

        public long IdDoctor { get; set; }
        public string NombresDoctor { get; set; }
        public string EspecialidadDoctor { get; set; }
        public int NumeroCredencialDoctor { get; set; }
        public string HospitalDoctor { get; set; }
        public int TelefonoDoctor { get; set; }
        public int IdentificacionDoctor { get; set; }

        public virtual ICollection<Consulta> Consulta { get; set; }
    }
}

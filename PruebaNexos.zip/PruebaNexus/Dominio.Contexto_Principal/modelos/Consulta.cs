﻿using System;
using System.Collections.Generic;

namespace Dominio.Contexto_Principal.modelos
{
    public partial class Consulta
    {
        public long IdConsulta { get; set; }
        public long IdDoctor { get; set; }
        public long IdPaciente { get; set; }
        public DateTime FechaConsulta { get; set; }
        public string ConsultorioCita { get; set; }

        public virtual Doctores IdDoctorNavigation { get; set; }
        public virtual Pacientes IdPacienteNavigation { get; set; }
    }
}

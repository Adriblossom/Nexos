﻿#region Directivas
using DotNetCore.Objects;
using Transversal.Excepcion;
using Infraestructura.Transversal.Log.Implementacion;
using Serilog;
#endregion

namespace Aplicacion.ContextoPrincipal.Base
{
    public abstract class BaseServicio
    {

        protected ErrorDataResult<T> ErrorDataResult<T>(string message)
        {
            //_logger.Information(message);
            SerilogFactory.Create().LogInformation(message, PoliticaExcepcionEnum.Aplicacion, null);
            return new ErrorDataResult<T>(message);
        }

        protected ErrorResult ErrorResult()
        {
            return new ErrorResult();
        }

        protected ErrorResult ErrorResult(string message)
        {
            //_logger.Information(message);
            SerilogFactory.Create().LogInformation(message, PoliticaExcepcionEnum.Aplicacion, null);
            return new ErrorResult(message);
        }

        protected SuccessDataResult<T> SuccessDataResult<T>(T data)
        {
            return new SuccessDataResult<T>(data);
        }

        protected SuccessResult SuccessResult()
        {
            return new SuccessResult();
        }


    }
}

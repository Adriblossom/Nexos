﻿using Infraestructura.Transversal.Adaptador;

namespace Aplicacion.ContextoPrincipal.Adaptador
{
    public static class AdaptadorExtensionMethods
    {
        public static TTarget Adaptar<TSource, TTarget>(this TSource source) where TTarget : class, new() where TSource : class
        {
            return AdaptadorTipoFactory.Create().Adapt<TSource, TTarget>(source);
        }

        /// <summary>
        /// Adapta según los parámetros especificados
        /// </summary>
        /// <typeparam name="TSource">valores de la llave asociados a la entidad</typeparam>
        /// <typeparam name="TTarget">valores de la llave asociados a la entidad</typeparam>
        /// <param name="source">Instance to adapt</param>
        /// <param name="llaveEncriptacion">valores de la llave asociados a la entidad</param>
        /// <param name="cifradoEstatico">Indica si se debe utilizar cifrado estático</param>
        /// <returns></returns>
        public static TTarget Adaptar<TSource, TTarget>(this TSource source, string llaveEncriptacion, bool cifradoEstatico = false)
            where TTarget : class, new()
            where TSource : class
        {
            return AdaptadorTipoFactory.Create().Adapt<TSource, TTarget>(source, llaveEncriptacion);
        }
    }
}

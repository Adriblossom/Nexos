﻿using Aplicacion.ContextoPrincipal.Modelos;
using Dominio.Contexto_Principal.modelos;
using DotNetCore.Objects;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Aplicacion.ContextoPrincipal.Servicio.PacientesServicio.Contrato
{
    public interface IPacienteServicio: IDisposable
    {
        Task<IDataResult<List<PacienteModel>>> ConsultaPaciente();
        IDataResult<PacienteModel> ActualizarPaciente(PacienteModel pacienteModel);
        IDataResult<PacienteModel> InsertarPaciente(PacienteModel pacienteModel);
        Task<IResult> EliminarPaciente(string IdPaciente);
    }
}

﻿using Aplicacion.ContextoPrincipal.Adaptador;
using Aplicacion.ContextoPrincipal.Base;
using Aplicacion.ContextoPrincipal.Modelos;
using Aplicacion.ContextoPrincipal.Servicio.PacientesServicio.Contrato;
using Dominio.Contexto_Principal.modelos;
using Dominio.Contexto_Principal.Repositorio;
using DotNetCore.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicacion.ContextoPrincipal.Servicio.PacientesServicio.Implementacion
{
    public sealed class PacienteServicio : BaseServicio, IPacienteServicio
    {
        private IPacienteRepositorio _pacienteRepositorio { get; }

        public PacienteServicio(IPacienteRepositorio pacienteRepositorio)
        {
            _pacienteRepositorio = pacienteRepositorio;
        }
        public void Dispose()
        {
            _pacienteRepositorio.Dispose();
        }

        public async Task<IDataResult<List<PacienteModel>>> ConsultaPaciente()
        {
            try
            {
                List<PacienteModel> listaPacientes = new List<PacienteModel>();
                List<Pacientes> pa = _pacienteRepositorio.GetAll().ToList();

                foreach (var item in pa)
                {
                    PacienteModel pac = new PacienteModel();
                    pac.IdentificacionPaciente = item.IdentificacionPaciente;
                    pac.IdPaciente = item.IdPaciente;
                    pac.NombresPaciente = item.NombresPaciente;
                    pac.NumeroSeguroPaciente = item.NumeroSeguroPaciente;
                    pac.TelefonoPaciente = item.TelefonoPaciente;
                    pac.CorreoElectronico = item.CorreoElectronico;
                    pac.CodigoPostal = item.CodigoPostal;

                    listaPacientes.Add(pac);

                }


                return SuccessDataResult(listaPacientes);
            }
            catch (Exception e)
            {

                return ErrorDataResult<List<PacienteModel>>(e.Message);
            }

        }

        public IDataResult<PacienteModel> ActualizarPaciente(PacienteModel pacienteModel)
        {
            try
            {
                Pacientes pac = pacienteModel.Adaptar<PacienteModel, Pacientes>();
                _pacienteRepositorio.Modify(pac);
                this._pacienteRepositorio.unidadTrabajo.Commit();
                return SuccessDataResult(pac.Adaptar<Pacientes, PacienteModel>());
            }
            catch (Exception e)
            {

                return ErrorDataResult<PacienteModel>(e.Message);
            }

        }


        public IDataResult<PacienteModel> InsertarPaciente(PacienteModel pacienteModel)
        {
            try
            {
                Pacientes pac = pacienteModel.Adaptar<PacienteModel, Pacientes>();
                _pacienteRepositorio.Add(pac);
                this._pacienteRepositorio.unidadTrabajo.Commit();
                return SuccessDataResult(pac.Adaptar<Pacientes, PacienteModel>());
            }
            catch (Exception e)
            {

                return ErrorDataResult<PacienteModel>(e.Message);
            }

        }

        public async Task<IResult> EliminarPaciente( string IdPaciente)
        {
            try
            {
                if (IdPaciente == null || IdPaciente == null)
                {
                    return ErrorDataResult<PacienteModel>("Error en la peticion.");
                }
                Pacientes paciente = new Pacientes() { IdPaciente = Convert.ToInt64(IdPaciente) };

                _pacienteRepositorio.Remove(paciente);
                await _pacienteRepositorio.unidadTrabajo.CommitAsync();

                return SuccessResult();
            }
            catch (Exception e)
            {

                return ErrorResult(e.Message);
            }
           
        }

    }
}

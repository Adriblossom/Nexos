﻿using Aplicacion.ContextoPrincipal.Modelos;
using Dominio.Contexto_Principal.modelos;
using DotNetCore.Objects;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Aplicacion.ContextoPrincipal.Servicio.DoctoresServicio.Contrato
{
    public interface IDoctorServicio : IDisposable
    {
        Task<IDataResult<List<DoctorModel>>> ConsultaDoctor();
        IDataResult<DoctorModel> ActualizarDoctor(DoctorModel DoctorModel);
        IDataResult<DoctorModel> InsertarDoctor(DoctorModel DoctorModel);
        Task<IResult> EliminarDoctor(string IdDoctor);
    }
}

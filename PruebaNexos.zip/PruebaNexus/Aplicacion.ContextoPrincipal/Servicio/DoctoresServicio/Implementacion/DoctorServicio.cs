﻿using Aplicacion.ContextoPrincipal.Adaptador;
using Aplicacion.ContextoPrincipal.Base;
using Aplicacion.ContextoPrincipal.Modelos;
using Aplicacion.ContextoPrincipal.Servicio.DoctoresServicio.Contrato;
using Dominio.Contexto_Principal.modelos;
using Dominio.Contexto_Principal.Repositorio.ContratoRepositorio;
using DotNetCore.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicacion.ContextoPrincipal.Servicio.DoctoresServicio.Implementacion
{
    public class DoctorServicio : BaseServicio, IDoctorServicio
    {
        private IDoctorRepositorio _doctorRepositorio { get; }

        public DoctorServicio(IDoctorRepositorio doctorRepositorio)
        {
            _doctorRepositorio = doctorRepositorio;
        }
        public void Dispose()
        {
           
        }

        public async Task<IDataResult<List<DoctorModel>>> ConsultaDoctor()
        {
            try
            {
                List<DoctorModel> listaDoctores = new List<DoctorModel>();
                List<Doctores> doc = _doctorRepositorio.GetAll().ToList();

                foreach (var item in doc)
                {
                    DoctorModel pac = new DoctorModel();
                    pac.IdDoctor = item.IdDoctor;
                    pac.NombresDoctor = item.NombresDoctor;
                    pac.IdentificacionDoctor = item.IdentificacionDoctor;
                    pac.NumeroCredencialDoctor = item.IdentificacionDoctor;
                    pac.TelefonoDoctor = item.TelefonoDoctor;
                    pac.HospitalDoctor = item.HospitalDoctor;
                    pac.EspecialidadDoctor = item.EspecialidadDoctor;

                    listaDoctores.Add(pac);

                }


                return SuccessDataResult(listaDoctores);
            }
            catch (Exception e)
            {

                return ErrorDataResult<List<DoctorModel>>(e.Message);
            }

        }

        public IDataResult<DoctorModel> ActualizarDoctor(DoctorModel DoctorModel)
        {
            try
            {
                Doctores doc = DoctorModel.Adaptar<DoctorModel, Doctores>();
                _doctorRepositorio.Modify(doc);
                this._doctorRepositorio.unidadTrabajo.Commit();
                return SuccessDataResult(doc.Adaptar<Doctores, DoctorModel>());
            }
            catch (Exception e)
            {

                return ErrorDataResult<DoctorModel>(e.Message);
            }

        }


        public IDataResult<DoctorModel> InsertarDoctor(DoctorModel DoctorModel)
        {
            try
            {
                Doctores doc = DoctorModel.Adaptar<DoctorModel, Doctores>();
                _doctorRepositorio.Add(doc);
                this._doctorRepositorio.unidadTrabajo.Commit();
                return SuccessDataResult(doc.Adaptar<Doctores, DoctorModel>());
            }
            catch (Exception e)
            {

                return ErrorDataResult<DoctorModel>(e.Message);
            }

        }

        public async Task<IResult> EliminarDoctor(string IdDoctor)
        {
            try
            {
                if (IdDoctor == null || IdDoctor == null)
                {
                    return ErrorDataResult<DoctorModel>("Error en la peticion.");
                }
                Doctores paciente = new Doctores() { IdDoctor = Convert.ToInt64(IdDoctor) };

                _doctorRepositorio.Remove(paciente);
                await _doctorRepositorio.unidadTrabajo.CommitAsync();

                return SuccessResult();
            }
            catch (Exception e)
            {

                return ErrorResult(e.Message);
            }

        }
    }
}

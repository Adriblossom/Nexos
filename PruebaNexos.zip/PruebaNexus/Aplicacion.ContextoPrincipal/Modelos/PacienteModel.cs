﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aplicacion.ContextoPrincipal.Modelos
{
    public class PacienteModel
    {
        public long IdPaciente { get; set; }
        public string NombresPaciente { get; set; }
        public int IdentificacionPaciente { get; set; }
        public string NumeroSeguroPaciente { get; set; }
        public int TelefonoPaciente { get; set; }
        public int CodigoPostal { get; set; }
        public string CorreoElectronico { get; set; }
    }
}

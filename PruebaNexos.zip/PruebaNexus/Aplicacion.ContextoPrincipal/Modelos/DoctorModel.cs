﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aplicacion.ContextoPrincipal.Modelos
{
    public class DoctorModel
    {
        public long IdDoctor { get; set; }
        public string NombresDoctor { get; set; }
        public string EspecialidadDoctor { get; set; }
        public int NumeroCredencialDoctor { get; set; }
        public string HospitalDoctor { get; set; }
        public int TelefonoDoctor { get; set; }
        public int IdentificacionDoctor { get; set; }
    }
}
